const socket = io({ transports: ['websocket'], secure: true });

let username = '', room = '';

function joinRoom() {
    username = document.getElementById('username').value;
    room = document.getElementById('room').value;
    if (username && room) {
        socket.emit('join_room', { username, room });
        document.getElementById('chatbox').innerHTML = '';
    }
}

function sendMessage() {
    const msg = document.getElementById('message').value;
    if (msg) {
        socket.emit('room_message', { username, msg, room });
        document.getElementById('message').value = '';
    }
    

    const file = document.getElementById('fileInput').files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function () {
            const arrayBuffer = reader.result;
            socket.emit('send_file', {
                filedata: new Uint8Array(arrayBuffer),
                filename: file.name,
                room: room
            });
        };
        reader.readAsArrayBuffer(file);
    }
}

function scrollChatbox() {
    const chatbox = document.getElementById('chatbox');
    chatbox.scrollTop = chatbox.scrollHeight;
}

socket.on('message', data => {
    const chatbox = document.getElementById('chatbox');
    chatbox.innerHTML += <p><strong>${data.username}</strong> [${data.time}]: ${data.msg}</p>;
});

socket.on('announcement', data => {
    const chatbox = document.getElementById('chatbox');
    chatbox.innerHTML += <p style="color:gray;"><em>${data.msg}</em></p>;
});

socket.on('file_uploaded', data => {
    const chatbox = document.getElementById('chatbox');
    chatbox.innerHTML += <p><a href="${data.url}" download>${data.filename}</a></p>;
});