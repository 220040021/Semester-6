# Program Python sederhana untuk menampilkan teks
nama = "IRVANDANI"
nim = "220040021"

# Menampilkan output
print(f"Perkenalkan, nama saya {nama} dan NIM: {nim}")
