const socket = io();

socket.on('message', function(data) {
    const chatBox = document.getElementById('chat-box');
    chatBox.innerHTML += `<div class="msg">${data}</div>`;
    chatBox.scrollTop = chatBox.scrollHeight; // Auto scroll ke bawah
});

socket.on('file_uploaded', function(data) {
    const chatBox = document.getElementById('chat-box');
    chatBox.innerHTML += `<div class="msg"><a href="/uploads/${data.filename}" target="_blank">${data.filename}</a></div>`;
    chatBox.scrollTop = chatBox.scrollHeight; // Auto scroll ke bawah
});

function sendMessage() {
    const msg = document.getElementById('message').value;
    if (msg.trim()) {
        socket.emit('message', msg);
        document.getElementById('message').value = '';
    }
}

document.getElementById('uploadForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const fileInput = document.getElementById('fileInput');
    if (fileInput.files.length > 0) {
        const formData = new FormData();
        formData.append("file", fileInput.files[0]);

        fetch('/upload', {
            method: 'POST',
            body: formData
        });
    }
});
